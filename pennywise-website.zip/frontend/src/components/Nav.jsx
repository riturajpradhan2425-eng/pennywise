import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Logo } from "./Logo";
import { scrollToId } from "../lib/scroll";
import { MintButton } from "./anim";

const LINKS = [
  ["The Problem", "#problem"],
  ["Validation", "#validation"],
  ["Demo", "#demo"],
  ["Features", "#features"],
  ["Roadmap", "#roadmap"],
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);

  return (
    <motion.header
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
      data-testid="site-nav"
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "border-b border-line bg-surface-1/85 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-6">
        <a
          href="#top"
          onClick={scrollToId("#top")}
          data-testid="nav-logo-link"
          className="flex items-center gap-2.5"
        >
          <Logo />
          <span className="font-heading text-lg font-bold tracking-tight text-white">
            Penny<span className="text-mint">Wise</span>
          </span>
        </a>

        <nav className="hidden items-center gap-8 lg:flex">
          {LINKS.map(([label, hash]) => (
            <a
              key={hash}
              href={hash}
              onClick={scrollToId(hash)}
              data-testid={`nav-link-${hash.slice(1)}`}
              className="group relative text-sm font-medium text-mist transition-colors hover:text-white"
            >
              {label}
              <span className="absolute -bottom-1 left-0 h-px w-0 bg-mint transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <MintButton testid="nav-cta-start" onClick={scrollToId("#demo")} className="!px-5 !py-2.5">
          Start Tracking
        </MintButton>
      </div>
    </motion.header>
  );
}
