import { useEffect, Component } from "react";
import Lenis from "lenis";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Problem from "./components/Problem";
import Validation from "./components/Validation";
import Demo from "./components/Demo";
import Features from "./components/Features";
import Comparison from "./components/Comparison";
import TechStack from "./components/TechStack";
import Roadmap from "./components/Roadmap";
import Footer from "./components/Footer";

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { err: false };
  }
  static getDerivedStateFromError() {
    return { err: true };
  }
  render() {
    if (this.state.err) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-ink font-sans text-mist">
          Something went wrong. Refresh to try again.
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.09, smoothWheel: true });
    window.__lenis = lenis;
    let raf;
    const loop = (t) => {
      lenis.raf(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
      window.__lenis = null;
    };
  }, []);

  return (
    <ErrorBoundary>
      <div className="bg-ink font-sans text-white antialiased">
        <div className="grain" aria-hidden="true" />
        <Nav />
        <main>
          <Hero />
          <Problem />
          <Validation />
          <Demo />
          <Features />
          <Comparison />
          <TechStack />
          <Roadmap />
        </main>
        <Footer />
      </div>
    </ErrorBoundary>
  );
}
